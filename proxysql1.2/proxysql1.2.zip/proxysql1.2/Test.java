package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Test{
  public static void main(String[] args) throws Exception{
    Class.forName("xoj.sql.proxy.ProxyDriver");
    Connection conn=DriverManager.getConnection("jdbc:proxy:testAccess");
    Statement stmt=conn.createStatement();
    ResultSet rs=stmt.executeQuery("select * from table1");
    while(rs.next()){
      System.out.println(rs.getString(1));
    }
  }
}
